<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Detail Peminjam</h4>
        <div class="table-responsive">
          <table class="table table-bordered">
            <tr>
              <th>Nama Produk</th>
              <td>Kredit Tanpa Agunan (KTA)</td>
            </tr>
            <tr>
              <th>Nama Peminjam</th>
              <td><?php echo e($data->nama_peminjam); ?></td>
            </tr>
            <tr>
              <th>Tujuan Penggunaan</th>
              <td><?php echo e($data->kta->tujuan_penggunaan); ?></td>
            </tr>
            <tr>
              <th>Jenis Agunan</th>
              <td><?php echo e($data->agunan->jenis_agunan); ?></td>
            </tr>
            <tr>
              <th>Nama Pemilik Agunan</th>
              <td><?php echo e($data->agunan->nama_pemilik_agunan); ?></td>
            </tr>
            <tr>
              <th>Jenis Pengikat</th>
              <td><?php echo e($data->agunan->jenis_pengikat); ?></td>
            </tr>
            <tr>
              <th>Nilai Pengikatan</th>
              <td><?php echo e($data->agunan->nilai_pengikatan); ?></td>
            </tr>
            <tr>
              <th>Keterangan</th>
              <td><?php echo e($data->agunan->keterangan); ?></td>
            </tr>
            <tr>
              <th>Status</th>
              <td><?php echo e($data->status); ?></td>
            </tr>
          </table>
        </div>
        <div class="d-flex justify-content-between mt-3">
          <a href="<?php echo e(route('pinjaman.index')); ?>" class="btn btn-danger">Kembali</a>
          <?php if($data->status): ?>
          <form action="<?php echo e(route('markAsFinished', $data->id_pinjaman)); ?>" method="POST">
            <?php echo e(@csrf_field()); ?>

            <button type="submit" class="btn btn-success">Sudah Selesai</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>