<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agunan;
use App\Models\Pinjaman;
use App\Models\ProdukPinjaman;

class DashboardController extends Controller
{
    public function index() {
        $kredit = Pinjaman::count();
        $kredit1 = Pinjaman::where('status', 'Belum Selesai')
            ->count();
        $kredit2 = Pinjaman::where('status', 'Selesai')
            ->count();
        $total = Agunan::sum('nilai_pengikatan');
        $total1 = Pinjaman::where('status', 'Belum Selesai')
            ->with('agunan')
            ->get()
            ->sum(function ($pinjaman) {
                return $pinjaman->agunan->nilai_pengikatan;
            });
        $total2 = Pinjaman::where('status', 'Selesai')
            ->with('agunan')
            ->get()
            ->sum(function ($pinjaman) {
                return $pinjaman->agunan->nilai_pengikatan;
            });

        $totalNilaiPengikatanAllProducts = ProdukPinjaman::with(['pinjaman.agunan'])
            ->get()
            ->flatMap(function ($produk) {
                return $produk->pinjaman;
            })
            ->sum(function ($pinjaman) {
                return $pinjaman->agunan ? $pinjaman->agunan->nilai_pengikatan : 0;
            });
        $produk = ProdukPinjaman::with(['pinjaman.agunan'])
            ->get()
            ->map(function ($produk) use ($totalNilaiPengikatanAllProducts) {
                $totalNilaiPengikatanProduct = $produk->pinjaman->sum(function ($pinjaman) {
                    return $pinjaman->agunan ? $pinjaman->agunan->nilai_pengikatan : 0;
                });
        
                $percentage = $totalNilaiPengikatanAllProducts > 0 ? ($totalNilaiPengikatanProduct / $totalNilaiPengikatanAllProducts) * 100 : 0;
        
                return [
                    'no' => $produk->id_produk,
                    'nama_produk' => $produk->nama_produk,
                    'percentage' => $percentage,
                    'total_nilai_pengikatan' => $totalNilaiPengikatanProduct,
                ];
            });
        

        return view('dashboard', compact('total','total1','total2','kredit','kredit1','kredit2','produk', 'totalNilaiPengikatanAllProducts'));
    }
}
