<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Detail Peminjam</h4>
        <div class="table-responsive">
          <table class="table table-bordered">
            <tr>
              <th>Nama Produk</th>
              <td><?php echo e($data->nama_produk); ?></td>
            </tr>
            <tr>
              <th>Nama Peminjam</th>
              <td><?php echo e($data->nama_peminjam); ?></td>
            </tr>
            <tr>
              <th>Jenis Usaha</th>
              <td><?php echo e($data->jenis_usaha); ?></td>
            </tr>
            <tr>
              <th>Jenis Agunan</th>
              <td><?php echo e($data->jenis_agunan); ?></td>
            </tr>
            <tr>
              <th>Nama Pemilik Agunan</th>
              <td><?php echo e($data->nama_pemilik_agunan); ?></td>
            </tr>
            <tr>
              <th>Jenis Pengikat</th>
              <td><?php echo e($data->jenis_pengikat); ?></td>
            </tr>
            <tr>
              <th>Nilai Pengikatan</th>
              <td><?php echo e($data->nilai_pengikatan); ?></td>
            </tr>
            <tr>
              <th>Keterangan</th>
              <td><?php echo e($data->keterangan); ?></td>
            </tr>
            <tr>
              <th>Status</th>
              <td><?php echo e($data->status ? 'Masih Berjalan' : '-'); ?></td>
            </tr>
          </table>
        </div>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light mt-3">Kembali</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>