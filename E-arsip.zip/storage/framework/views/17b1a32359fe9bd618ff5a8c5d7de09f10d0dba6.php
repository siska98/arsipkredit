<?php $__env->startPush('plugin-styles'); ?>
  <!-- <?php echo Html::style('/assets/plugins/plugin.css'); ?> -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
    <div class="card card-statistics">
      <div class="card-body">
        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
          <div class="float-left">
            <i class="mdi mdi-receipt text-warning icon-lg"></i>
          </div>
          <div class="float-right">
            <p class="mb-0 text-right">Jumlah Kreditor</p>
            <div class="fluid-container">
              <h3 class="font-weight-medium text-right mb-0"><?php echo e($kredit); ?></h3>
            </div>
          </div>
        </div>
        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
    <div class="card card-statistics">
      <div class="card-body">
        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
          <div class="float-left">
            <i class="mdi mdi-poll-box text-success icon-lg"></i>
          </div>
          <div class="float-right">
            <p class="mb-0 text-right">Belum Selesai</p>
            <div class="fluid-container">
              <h3 class="font-weight-medium text-right mb-0"><?php echo e($kredit1); ?></h3>
            </div>
          </div>
        </div>
        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
      </div>
    </div>
  </div>
  <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 grid-margin stretch-card">
    <div class="card card-statistics">
      <div class="card-body">
        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
          <div class="float-left">
            <i class="mdi mdi-account-box-multiple text-info icon-lg"></i>
          </div>
          <div class="float-right">
            <p class="mb-0 text-right">Sudah Selesai</p>
            <div class="fluid-container">
              <h3 class="font-weight-medium text-right mb-0"><?php echo e($kredit2); ?></h3>
            </div>
          </div>
        </div>
        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6 col-xl-5 grid-margin stretch-card">
    <div class="card card-revenue">
      <div class="card-body d-flex align-items-center">
        <div class="d-flex flex-grow">
          <div class="mr-auto">
            <p class="text-white"> Total Transaksi </p>
            <p class="highlight-text mb-0 text-white">Rp.<?php echo e(number_format($total, 0, ',', '.')); ?></p>
            <div class="badge badge-pill"> <?php echo e(date('Y')); ?> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-xl-7 grid-margin stretch-card">
    <div class="card card-revenue-table">
      <div class="card-body">
        <div class="revenue-item d-flex">
          <div class="revenue-desc">
            <h6>Total Kredit Belum Selesai</h6>
          </div>
          <div class="revenue-amount">
            <p class="text-primary">Rp.<?php echo e(number_format($total1, 0, ',', '.')); ?></p>
          </div>
        </div>
        <div class="revenue-item d-flex">
          <div class="revenue-desc">
            <h6>Total Kredit Sudah Selesai</h6>
          </div>
          <div class="revenue-amount">
            <p class="text-primary">Rp.<?php echo e(number_format($total2, 0, ',', '.')); ?> </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-12 grid-margin">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">History Kredit Per Bulan</h4>
        <div class="table-responsive">
          <table class="table table-striped">
          <thead>
              <tr>
                <th> No </th>
                <th> Tahun </th>
                <th> Bulan </th>
                <th> Total Nilai Pengikatan </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $monthlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="font-weight-medium"> <?php echo e($index + 1); ?> </td>
                <td> <?php echo e($data['year']); ?> </td>
                <td> <?php echo e($data['month']); ?> </td>
                <td> Rp. <?php echo e(number_format($data['total_nilai_pengikatan'], 0, ',', '.')); ?> </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-12 grid-margin">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Produk Pinjaman</h4>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th> No </th>
                <th> Nama Produk </th>
                <th> Percentage </th>
                <th> Total Nilai Pengikatan </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="font-weight-medium"> <?php echo e($data['no']); ?> </td>
                <td> <?php echo e($data['nama_produk']); ?> </td>
                <td><div class="progress">
                    <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" style="width: <?php echo e(number_format($data['percentage'], 2)); ?>%" aria-valuenow="<?php echo e(number_format($data['percentage'], 2)); ?>%" aria-valuemin="0" aria-valuemax="100"></div>
                  </div><p><?php echo e(number_format($data['percentage'])); ?>%</p></td>
                <td> Rp. <?php echo e(number_format($data['total_nilai_pengikatan'], 0, ',', '.')); ?> </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
  <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

  <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
  <?php echo Html::script('/assets/js/dashboard.js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>