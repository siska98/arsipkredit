<footer class="footer">
  <div class="container-fluid clearfix">
  </div>
</footer>